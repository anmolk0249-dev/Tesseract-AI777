export default function Home() {
  return (
    <div style={{ textAlign: "center", marginTop: "50px" }}>
      <h1>🚀 My Next.js App</h1>
      <p>Deployed on Vercel successfully!</p>
    </div>
  );
}
